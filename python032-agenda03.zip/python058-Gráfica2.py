import matplotlib.pyplot as dibujar
dibujar.plot([1,5,3,7])
dibujar.ylabel("mi coleccion de numero")
dibujar.show()
