# Lista - Mutables - con corchetes
# Tuplas - Inmutables - parentesis

longaniza = ("uno","dos","tres","a")
morcilla = ["uno","dos","tres","a"]


morcilla[3] = "cuatro"

print(longaniza[1])
print(morcilla[1])

print(len(longaniza))
print(len(morcilla))
