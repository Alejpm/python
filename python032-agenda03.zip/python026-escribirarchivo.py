archivo = open("miarchivo.txt",'a')
archivo.write("Este es un text que estoy escribiendo")
archivo.close()
