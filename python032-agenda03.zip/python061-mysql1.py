import mysql.connector as my

mibd = my.connect(
    host = "127.0.0.1",
    user = "alejandro",
    password = "alejandro"
    )

print(mibd)
