# Documentación sobre la libería matemática
# https://docs.python.org/3/library/math.html

import math

print(math.sqrt(9))

print(math.ceil(3.3))

print(math.sin(math.pi))
