dia = "lunes"

if dia == 'lunes':
    print("hoy es el peor dia de la semana")
elif dia == 'martes':
    print("hoy es el segundo peor dia de la semana")
    elif dia == 'miercoles':
    print("ya estamos en el medio")
    elif dia == 'jueves':
    print("ya casi es fin de semana")
    elif dia == 'viernes':
    print("el mejor dia de la semana")
    elif dia == 'sabado':
    print("hoy es fin de semana")
    elif dia == 'domingo':
    print("y mañana es lunes")
    elif dia == 
    print("yo no se lo que has puesto, pero no es un día de la semana")
   
