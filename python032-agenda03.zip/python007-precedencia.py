

print(3 * (4 + 5))
      
