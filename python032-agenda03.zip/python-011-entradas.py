print("Dime tu nombre")
nombre = input()
#A continuacion quiero ver si el sistema guarda esa informacion
print("Hola,",nombre)

print("Dime tu edad")
edad = input()
print("Tu nombre es",nombre,",tu edad es de",edad,"años")
