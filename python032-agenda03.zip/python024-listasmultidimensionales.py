agenda = [2]
agenda[0] = ["JoseVicente","5434634","info@josevicentecarratala.com"]
agenda[1] = ["Juan","111111","juan@josevicentecarratala.com"]


print(agenda[0][1])
