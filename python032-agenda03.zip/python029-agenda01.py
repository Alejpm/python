##Programa agenda por Alejandro

agenda = [["nombre","telefono","email"]]


agenda.append([["nombre2","telefono2","email2"]])

print(agenda)


def miAgenda():
    print("Introduce el nuevo nombre en la agenda")
    nombre = input()
    print("Introduce el correo")
    telefono = input()
    miAgenda()
# antes de hacer nada mas, lo metemos en la lista, y sacamos la lista
    agenda.append([nombre,telefono,correo])
print(agenda)
# ejecucion recursiva

miAgenda() 
