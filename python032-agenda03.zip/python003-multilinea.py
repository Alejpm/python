print("Esto es una linea de texto")
print("Esto es una linea")
print("Esto es otra linea")
