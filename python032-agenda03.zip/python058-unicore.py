import time

numero = 0.00000000004234
contador = 0

def bucle():
    numero = numero + 1
    if contador % 100 == 0:
        print("ok la cosa va bien")
    numero = numero*1.2
    time.sleep(0.01)
    bucle()

time.sleep(1)
bucle()
    
