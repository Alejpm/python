print("Dime la edad")
edad = float(input())
print("El doble de tu edad es",(edad+2))

