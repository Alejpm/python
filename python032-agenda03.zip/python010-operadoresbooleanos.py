#print(3 == 3 and 4 == 4) True
#print(3 == 3 and 4 == 5) False

print(3 == 3 and 4 == 5)
