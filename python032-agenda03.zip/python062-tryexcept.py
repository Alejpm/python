
print(x)

try:
    print(x)
except:
    print("ha ocurrido algun error")
