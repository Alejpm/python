import mysql.connector as my
try:
    mibd = my.connect(
    host = "127.0.0.1",
    user = "alejandro",
    password = "alejandro",
    database = "cursopython"
    )

##print(mibd)

    micursor = mibd.cursor()

    micursor.execute("SELECT * FROM personas")

    miresultado = micursor.fetchall()

##print(miresultado)

    for i in miresultado:
        print("tengo un resultado que es:")
        print(i)
except:
        print("ha ocurrido algun error en la base de datos")
