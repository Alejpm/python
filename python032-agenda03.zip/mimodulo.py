def dimeHola():
    print("Yo te digo hola")

def dimeAdios():
    print("Yo te digo adios")

