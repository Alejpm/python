##Programa agenda por Alejandro

agenda = [["nombre","telefono","email"]]

#antes de nada, vamos a cargar los registros que teniamos en el archivo de texto
archivo = open("agenda.txt",'r')
for i in range(1,10):
    nuevalinea = archivo.readline().split(",")
    agenda.append(nuevalinea)

#antes de seguir, dime en que estado esta la agenda

def miAgenda():
  #Menu inicial
    print("Escoge tu opcion")
    print("1.-Introduce nuevo registro")
    print("2.-Listar registros")
    print("3.-Buscar registro")
    option = input()
    if option == "1":
    
        print("Introduce el nuevo nombre en la agenda")
        nombre = input()
        print("Introduce el numero de telefono")
        telefono = input()
        print("Introduce el correo")
        correo = input()
        
   # antes de hacer nada mas, lo metemos en la lista, y sacamos la lista
        agenda.append([nombre,telefono,correo])
   ## print(agenda)
   # guardo en archivo
        archivo = open("agenda.txt",'a')
        longaniza = nombre+","+telefono+","+correo+"\n"
        archivo.write(str(longaniza))                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
        archivo.close()
    if option == "2":
       for i in range(1,len(agenda)):
           print(agenda[i])
   # ejecucion recursiva
miAgenda()

miAgenda() 
