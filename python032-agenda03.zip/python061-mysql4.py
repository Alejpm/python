import mysql.connector as my
try:
    mibd = my.connect(
    host = "127.0.0.1",
    user = "alejandro",
    password = "alejandro",
    database = "cursopython"
    )

##print(mibd)

    micursor = mibd.cursor()

    micursor.execute("INSERT INTO personas VALUES (NULL,'jose','12345','jose@correo,com')")
    mibd.commit()

##print(miresultado)

except:
        print("ha ocurrido algun error en la base de datos")
